open class Veiculo (val marca: String, val modelo: String) {
    fun mover(){
        println("O veiculo $marca $modelo está se movendo.")
    }
}

open class Carro(marca: String, modelo: String) : Veiculo(marca, modelo){
    fun abastecer(){
        println("O carro $marca $modelo está sendo abastecido.")
    }
}

class Esportivo(marca: String, modelo: String) : Carro(marca,modelo) {
    fun turbo(){
        println("Turbina cheia $marca $modelo")
    }
}