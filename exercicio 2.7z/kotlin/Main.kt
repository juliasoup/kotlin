fun main(args: Array<String>) {

    val carro1 = Carro("Honda", "CivicSi",2022)
    val carro2 = Carro("Toyota", "Supra", 2015)

    println("Carro: ${carro1.marca} ${carro1.modelo}, ano ${carro1.ano}")
    println("Carro: ${carro2.marca} ${carro2.modelo}, ano ${carro2.ano}")


}
