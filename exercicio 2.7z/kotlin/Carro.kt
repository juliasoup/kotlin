class Carro {
    var marca: String
    var modelo: String
    var ano: Int

    constructor(marca: String, modelo: String, ano: Int){
        this.marca = marca
        this.modelo = modelo
        this.ano = ano
    }

}