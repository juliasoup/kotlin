fun main(args: Array<String>) {
    val carrodopipoco = Esportivo()

    carrodopipoco.mover()
    carrodopipoco.abastecer()
    carrodopipoco.turbo()
}
