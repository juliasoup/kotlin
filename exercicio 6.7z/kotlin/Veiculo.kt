open class Veiculo {
    fun mover(){
        println("O veiculo está se movendo.")
    }
}

open class Carro : Veiculo(){
    fun abastecer(){
        println("O carro está sendo abastecido.")
    }
}

class Esportivo : Carro() {
    fun turbo(){
        println("Turbina cheia")
    }
}