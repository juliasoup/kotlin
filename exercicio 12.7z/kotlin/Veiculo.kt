interface Veiculo {
    val VELOCIDADE_MAXIMA: Int

}

class Carro : Veiculo {
    override val VELOCIDADE_MAXIMA = 180

    var velocidadeAtual = 0

    fun acelerar(velocidade: Int){
        if(velocidade <= VELOCIDADE_MAXIMA){
            velocidadeAtual = velocidade
            println("Velocidade ajustada para $velocidadeAtual Km/h.")

        } else {
            velocidadeAtual = VELOCIDADE_MAXIMA
            println("velocidade maxima atingida: $VELOCIDADE_MAXIMA Km/h.")
        }
    }
}