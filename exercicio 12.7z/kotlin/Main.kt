fun main(args: Array<String>) {
        val carro = Carro()

        carro.acelerar(120)
        carro.acelerar(181)
    }

